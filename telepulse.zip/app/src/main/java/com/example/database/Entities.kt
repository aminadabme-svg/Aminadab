package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val type: String, // PRIVATE, GROUP, CHANNEL, BOT
    val lastMessage: String?,
    val lastMessageTime: Long,
    val avatarUrl: String?,
    val isPinned: Boolean = false,
    val unreadCount: Int = 0
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: Long,
    val senderName: String,
    val text: String,
    val timestamp: Long,
    val isMe: Boolean,
    val type: String = "TEXT", // TEXT, IMAGE, VOICE, FILE
    val mediaUri: String? = null,
    val isTranslated: Boolean = false,
    val translatedText: String? = null,
    val isTranscribed: Boolean = false,
    val transcribedText: String? = null
)

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val senderName: String,
    val senderAvatar: String?,
    val imageUrl: String,
    val caption: String?,
    val timestamp: Long,
    val viewCount: Int = 0,
    val reaction: String? = null
)

@Entity(tableName = "user_sessions")
data class UserSessionEntity(
    @PrimaryKey val id: Long = 1, // Single-row session
    val name: String = "Admin",
    val phoneNumber: String = "+1 555-0199",
    val bio: String = "Building the future of secure communication ✨",
    val isLoggedIn: Boolean = false,
    val avatarUri: String? = null,
    val biometricEnabled: Boolean = false,
    val passCode: String? = null
)
