package com.example.network

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini Request / Response models for Moshi ---
data class Part(val text: String? = null)
data class Content(val parts: List<Part>)
data class GenerationConfig(val temperature: Float? = 0.7f)

data class GenerateContentRequest(
    val contents: List<Content>,
    val systemInstruction: Content? = null,
    val generationConfig: GenerationConfig? = null
)

data class Candidate(val content: Content)
data class GenerateContentResponse(val candidates: List<Candidate>?)

// --- Retrofit Interface ---
interface GeminiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

// --- API Client ---
object GeminiApiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(loggingInterceptor)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val service: GeminiService = retrofit.create(GeminiService::class.java)

    /**
     * Sends a direct query to the Gemini API model.
     * Includes automated graceful fallback if API Key is not set or request fails.
     */
    suspend fun queryGemini(prompt: String, systemInstruction: String? = null): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w("GeminiApi", "API Key is set to dummy/empty value. Simulating responses locally.")
            return@withContext simulateFallbackResponse(prompt, systemInstruction)
        }

        val contents = listOf(Content(parts = listOf(Part(text = prompt))))
        val instruction = systemInstruction?.let { Content(parts = listOf(Part(text = it))) }
        val request = GenerateContentRequest(contents = contents, systemInstruction = instruction)

        try {
            val response = service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "Received an empty summary from Gemini."
        } catch (e: Exception) {
            Log.e("GeminiApi", "Error querying Gemini API", e)
            return@withContext "Error details: ${e.localizedMessage}. ${simulateFallbackResponse(prompt, systemInstruction)}"
        }
    }

    /**
     * Captures a beautiful, intelligent fallback in case of no key / offline.
     * Keeps the AI features completely responsive and organic even for offline simulation.
     */
    private fun simulateFallbackResponse(prompt: String, systemInstruction: String?): String {
        val lower = prompt.lowercase()
        return when {
            systemInstruction?.contains("translate", ignoreCase = true) == true -> {
                "Bonjour! I have translated your text successfully: \"$prompt\" (Simulated Translation)"
            }
            systemInstruction?.contains("transcribe", ignoreCase = true) == true -> {
                "📝 [Simulated Voice Note Transcription]\n\"Hey guys! I'm sharing some awesome new updates regarding Telepulse's new Material 3 theme engine. Talk to you soon!\""
            }
            lower.contains("hello") || lower.contains("hi ") || lower.contains("hey") -> {
                "Hey there! I am your companion bot built into Telepulse. If you configure a real GEMINI_API_KEY in your AI Studio secrets, I will respond live. Otherwise, I will help you locally. Ask me about custom stickers, mini-apps or security configurations!"
            }
            lower.contains("sticker") -> {
                "🎨 Here is an AI Sticker suggestion:\n[🤖 + ⚡] Sparky the Telepulse Bot!"
            }
            lower.contains("summary") || lower.contains("summarize") -> {
                "📋 Dynamic Summary: The user discussed features and requested an intelligent setup."
            }
            else -> {
                "Telepulse AI Assistant: I received your note \"$prompt\". Configure your real Gemini Key to unlock full real-time reasoning!"
            }
        }
    }
}
