package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.AppDatabase
import com.example.database.ChatEntity
import com.example.database.MessageEntity
import com.example.database.StoryEntity
import com.example.database.UserSessionEntity
import com.example.repository.TeleRepository
import com.example.ui.theme.TelepulseThemeType
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface AuthState {
    object EnterPhone : AuthState
    data class EnterOtp(val phoneNumber: String) : AuthState
    object Authenticated : AuthState
}

class TeleViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = TeleRepository(db)

    // --- Core states ---
    val chats: StateFlow<List<ChatEntity>> = repository.allChats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stories: StateFlow<List<StoryEntity>> = repository.allStories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userSession: StateFlow<UserSessionEntity?> = repository.userSession
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Transitioning Auth States
    private val _authState = MutableStateFlow<AuthState>(AuthState.EnterPhone)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    // Active Chat Selection
    private val _activeChatId = MutableStateFlow<Long?>(null)
    val activeChatId: StateFlow<Long?> = _activeChatId.asStateFlow()

    // Observable Messages for selected chat
    val activeMessages: StateFlow<List<MessageEntity>> = _activeChatId
        .flatMapLatest { chatId ->
            if (chatId != null) {
                repository.clearUnread(chatId) // Auto clear unread on enter
                repository.getMessagesForChat(chatId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Layout & System states ---
    private val _appTheme = MutableStateFlow(TelepulseThemeType.TELEGRAM_DARK)
    val appTheme: StateFlow<TelepulseThemeType> = _appTheme.asStateFlow()

    // Call States
    private val _isCallActive = MutableStateFlow(false)
    val isCallActive: StateFlow<Boolean> = _isCallActive.asStateFlow()

    private val _callStateMessage = MutableStateFlow("Disconnected")
    val callStateMessage: StateFlow<String> = _callStateMessage.asStateFlow()

    private val _callerName = MutableStateFlow("Alex")
    val callerName: StateFlow<String> = _callerName.asStateFlow()

    private val _callType = MutableStateFlow("VOICE") // VOICE or VIDEO
    val callType: StateFlow<String> = _callType.asStateFlow()

    // Premium Call controls (simulated noise-cancelling and screen-sharing toggle)
    private val _noiseCancelEnabled = MutableStateFlow(true)
    val noiseCancelEnabled: StateFlow<Boolean> = _noiseCancelEnabled.asStateFlow()

    private val _screenShareEnabled = MutableStateFlow(false)
    val screenShareEnabled: StateFlow<Boolean> = _screenShareEnabled.asStateFlow()

    // Bot Typing and Processing animation helpers
    private val _aiProcessing = MutableStateFlow(false)
    val aiProcessing: StateFlow<Boolean> = _aiProcessing.asStateFlow()

    // Interactive AI summary string
    private val _chatSummaryResult = MutableStateFlow("")
    val chatSummaryResult: StateFlow<String> = _chatSummaryResult.asStateFlow()

    // Wallet/Mini-App properties (Coin Clicker + Crypto balance)
    private val _miniAppTokens = MutableStateFlow(750)
    val miniAppTokens: StateFlow<Int> = _miniAppTokens.asStateFlow()

    private val _walletBalanceUsd = MutableStateFlow(124.50)
    val walletBalanceUsd: StateFlow<Double> = _walletBalanceUsd.asStateFlow()

    // Admin Logging Statistics
    val totalLogMessages = MutableStateFlow<List<String>>(
        listOf(
            "[SEC] Session initialized under secure token payload AES-256",
            "[DB] SQLite indexed correctly on PRIMARY KEY user_sessions",
            "[NET] Websocket server bound successfully mapping ports",
            "[AI] Gemini module attached using model spec gemini-3.5-flash",
            "[APP] Telepulse launcher ready..."
        )
    )

    init {
        viewModelScope.launch {
            repository.initializeDefaultDataIfRequired()
            
            // Check logged in status directly from local database user sessions
            sessionFirstCheck()
        }
    }

    private suspend fun sessionFirstCheck() {
        userSession.collectLatest { session ->
            if (session != null) {
                if (session.isLoggedIn) {
                    _authState.value = AuthState.Authenticated
                } else {
                    _authState.value = AuthState.EnterPhone
                }
            }
        }
    }

    // --- Actions ---

    fun verifyPhone(phoneNumber: String) {
        viewModelScope.launch {
            // Transitions to OTP stage securely
            _authState.value = AuthState.EnterOtp(phoneNumber)
            addLog("Auth requested verification SMS dispatch to target phone: $phoneNumber")
        }
    }

    fun verifyOtp(otp: String) {
        viewModelScope.launch {
            if (otp == "7777" || otp.length == 4) { // Let master sandbox passcode bypass
                repository.updateLoginState(true)
                _authState.value = AuthState.Authenticated
                addLog("OTP validated correctly. Access-token generated.")
            } else {
                addLog("[ERR] OTP mismatch for authentication key.")
            }
        }
    }

    fun loginViaQR() {
        viewModelScope.launch {
            repository.updateLoginState(true)
            _authState.value = AuthState.Authenticated
            addLog("QR Code linked authenticated companion workspace sync.")
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.updateLoginState(false)
            _authState.value = AuthState.EnterPhone
            _activeChatId.value = null
            addLog("Session logged out. Secure cache keys cleared locally.")
        }
    }

    fun selectChat(chatId: Long?) {
        _activeChatId.value = chatId
        _chatSummaryResult.value = "" // Reset summary on transition
        if (chatId != null) {
            viewModelScope.launch {
                repository.clearUnread(chatId)
            }
            addLog("Active conversation focal shift to Id: $chatId")
        }
    }

    fun sendMessage(text: String, type: String = "TEXT", mediaUri: String? = null) {
        val chatId = _activeChatId.value ?: return
        if (text.isBlank() && mediaUri == null) return

        viewModelScope.launch {
            if (chatId == 101L) {
                _aiProcessing.value = true
            }
            // Send to DB via Repo
            repository.sendMessage(chatId, text, type, mediaUri)
            _aiProcessing.value = false
            addLog("Message sent type: $type to Chat: $chatId")
        }
    }

    fun translateMessage(message: MessageEntity, language: String) {
        viewModelScope.launch {
            _aiProcessing.value = true
            repository.translateMessage(message, language)
            _aiProcessing.value = false
            addLog("AI translate content executed for Message Id: ${message.id}")
        }
    }

    fun transcribeVoice(message: MessageEntity) {
        viewModelScope.launch {
            _aiProcessing.value = true
            repository.transcribeMessage(message)
            _aiProcessing.value = false
            addLog("AI audio transcription executed for Message Id: ${message.id}")
        }
    }

    fun deleteMessage(messageId: Long) {
        viewModelScope.launch {
            repository.deleteMessage(messageId)
            addLog("Message deleted locally Id: $messageId")
        }
    }

    fun summarizeChatFeed() {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            _aiProcessing.value = true
            val msgs = activeMessages.value
            val summary = repository.summarizeChat(chatId, msgs)
            _chatSummaryResult.value = summary
            _aiProcessing.value = false
            addLog("AI chat transcription auto-recap produced for Chat: $chatId")
        }
    }

    // --- Calling Features ---
    fun initiateCall(caller: String, type: String) {
        _callerName.value = caller
        _callType.value = type
        _isCallActive.value = true
        _callStateMessage.value = "Connecting..."
        addLog("WebRTC Peer stream initialized ($type) to target peer: $caller")

        // Simulate successful connection state over 1.5 seconds
        viewModelScope.launch {
            kotlinx.coroutines.delay(1500)
            _callStateMessage.value = "Connected • Secure AES-256"
            addLog("WebRTC handshake completed. Peer feed synchronized.")
        }
    }

    fun endCall() {
        _isCallActive.value = false
        _callStateMessage.value = "Disconnected"
        addLog("Peer connection ended. Session reports 0% packet loss.")
    }

    fun toggleNoiseCancel() {
        _noiseCancelEnabled.value = !_noiseCancelEnabled.value
        addLog("Voice DSP audio filter noise-cancel toggled: ${_noiseCancelEnabled.value}")
    }

    fun toggleScreenShare() {
        _screenShareEnabled.value = !_screenShareEnabled.value
        addLog("Output screen buffer stream share state: ${_screenShareEnabled.value}")
    }

    // --- Story Feature Actions ---
    fun publishCustomStory(imageUri: String, caption: String?) {
        viewModelScope.launch {
            repository.publishStory(imageUri, caption)
            addLog("Custom story published with image: $imageUri")
        }
    }

    fun reactToStory(storyId: Long, reactionSymbol: String) {
        viewModelScope.launch {
            repository.addStoryReaction(storyId, reactionSymbol)
            addLog("Story Reaction added ($reactionSymbol) to Story: $storyId")
        }
    }

    // --- System Customizations ---
    fun changeSystemTheme(type: TelepulseThemeType) {
        _appTheme.value = type
        addLog("System color redraw initiated. Focal scheme mapped to $type")
    }

    fun updateProfileSettings(newName: String, newBio: String, biometric: Boolean, code: String?) {
        viewModelScope.launch {
            repository.updateSessionSettings(newName, newBio, biometric, code)
            addLog("Profile settings synchronized locally.")
        }
    }

    // --- Interactive Games / Mini App clicks ---
    fun claimTokens() {
        _miniAppTokens.value += 10
        _walletBalanceUsd.value += 0.45
        addLog("[MINI-APP] Claimed 10 PULSE. Balance updated.")
    }

    // Logging helpers
    private fun addLog(text: String) {
        val list = totalLogMessages.value.toMutableList()
        val formattedLog = "[${System.currentTimeMillis() % 100000}] $text"
        list.add(formattedLog)
        if (list.size > 20) list.removeAt(0)
        totalLogMessages.value = list
    }
}
