package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.viewmodel.TeleViewModel
import com.example.ui.TelepulseMainApp

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
       val viewModel: TeleViewModel = viewModel()
       TelepulseMainApp(viewModel = viewModel)
    }
  }
}
