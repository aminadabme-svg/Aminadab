package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class TelepulseThemeType {
    TELEGRAM_LIGHT,
    TELEGRAM_DARK,
    AMOLED_PREMIUM,
    COSMIC_EMERALD,
    VINTAGE_AMBER
}

private val TelegramLightColorScheme = lightColorScheme(
    primary = TelegramBlueLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD2E4F2),
    onPrimaryContainer = TelegramBlueLight,
    secondary = Color(0xFF536DFE),
    background = Color(0xFFF5F7F9),
    surface = Color.White,
    onBackground = Color(0xFF212121),
    onSurface = Color(0xFF212121)
)

private val TelegramDarkColorScheme = darkColorScheme(
    primary = TelegramBlueDark,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF1B2F44),
    onPrimaryContainer = TelegramBlueDark,
    secondary = Color(0xFF40B3FF),
    background = ChatBgDark,
    surface = Color(0xFF17212B),
    onBackground = Color.White,
    onSurface = Color.White
)

private val AmoledPremiumColorScheme = darkColorScheme(
    primary = AmoledAccent,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF3C096C),
    onPrimaryContainer = AmoledAccent,
    secondary = Color(0xFFC77DFF),
    background = AmoledBackground,
    surface = AmoledSurface,
    onBackground = Color.White,
    onSurface = Color.White
)

private val CosmicEmeraldColorScheme = darkColorScheme(
    primary = CosmicBrightGreen,
    onPrimary = Color.Black,
    primaryContainer = CosmicLeaf,
    onPrimaryContainer = CosmicBrightGreen,
    secondary = Color(0xFF2EC4B6),
    background = CosmicForest,
    surface = CosmicLeaf,
    onBackground = Color.White,
    onSurface = Color.White
)

private val VintageAmberColorScheme = darkColorScheme(
    primary = CyberpunkAmber,
    onPrimary = Color.Black,
    primaryContainer = CyberpunkCard,
    onPrimaryContainer = CyberpunkAmber,
    secondary = Color(0xFFFFB300),
    background = CyberpunkBackground,
    surface = CyberpunkObsidian,
    onBackground = CyberpunkAmber,
    onSurface = CyberpunkAmber
)

@Composable
fun TelepulseTheme(
    themeType: TelepulseThemeType = TelepulseThemeType.TELEGRAM_DARK,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeType) {
        TelepulseThemeType.TELEGRAM_LIGHT -> TelegramLightColorScheme
        TelepulseThemeType.TELEGRAM_DARK -> TelegramDarkColorScheme
        TelepulseThemeType.AMOLED_PREMIUM -> AmoledPremiumColorScheme
        TelepulseThemeType.COSMIC_EMERALD -> CosmicEmeraldColorScheme
        TelepulseThemeType.VINTAGE_AMBER -> VintageAmberColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
