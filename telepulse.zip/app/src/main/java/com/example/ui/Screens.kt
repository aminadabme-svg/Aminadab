package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.database.ChatEntity
import com.example.database.MessageEntity
import com.example.database.StoryEntity
import com.example.ui.theme.TelepulseThemeType
import com.example.viewmodel.AuthState
import com.example.viewmodel.TeleViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelepulseMainApp(viewModel: TeleViewModel) {
    val authState by viewModel.authState.collectAsState()
    val themeType by viewModel.appTheme.collectAsState()

    // Wrap entire layout under the dynamic system theme engine
    com.example.ui.theme.TelepulseTheme(themeType = themeType) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Crossfade(targetState = authState, label = "AuthenticationFlow") { state ->
                when (state) {
                    is AuthState.EnterPhone -> PhoneLoginView(
                        onPhoneSubmitted = { viewModel.verifyPhone(it) },
                        onQrClicked = { viewModel.loginViaQR() }
                    )
                    is AuthState.EnterOtp -> OtpLoginView(
                        phoneNumber = state.phoneNumber,
                        onOtpSubmitted = { viewModel.verifyOtp(it) },
                        onBack = { viewModel.logout() }
                    )
                    is AuthState.Authenticated -> AuthenticatedDashboard(viewModel)
                }
            }
        }
    }
}

// ==========================================
// 1. AUTHENTICATION SCREENS (OTP / QR LOGIN)
// ==========================================

@Composable
fun PhoneLoginView(onPhoneSubmitted: (String) -> Unit, onQrClicked: () -> Unit) {
    var phoneNumber by remember { mutableStateOf("") }
    val primaryColor = MaterialTheme.colorScheme.primary

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Aesthetic custom brand logo
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(primaryColor, primaryColor.copy(alpha = 0.5f))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Send,
                contentDescription = "Telepulse Vector Identity",
                tint = Color.White,
                modifier = Modifier
                    .size(48.dp)
                    .offset(x = (-3).dp) // Asymmetric elegant shift
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
        Text(
            text = "Telepulse Messenger",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Your secure real-time MTProto-simulated network. Enter your phone to sync.",
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(36.dp))

        OutlinedTextField(
            value = phoneNumber,
            onValueChange = { phoneNumber = it },
            label = { Text("Phone Number") },
            placeholder = { Text("+1 555-0199") },
            prefix = { Text("📱 ") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Phone,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = { if (phoneNumber.isNotBlank()) onPhoneSubmitted(phoneNumber) }
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("phone_input")
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = { if (phoneNumber.isNotBlank()) onPhoneSubmitted(phoneNumber) },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("phone_submit_button"),
            colors = ButtonDefaults.buttonColors(containerColor = primaryColor)
        ) {
            Text("Next • Send Code", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "OR SIGN IN WITH COMPANION QR",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = onQrClicked,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Scan QR Code Sync", fontSize = 14.sp)
        }
    }
}

@Composable
fun OtpLoginView(
    phoneNumber: String,
    onOtpSubmitted: (String) -> Unit,
    onBack: () -> Unit
) {
    var otpCode by remember { mutableStateOf("") }
    var countdown by remember { mutableIntStateOf(60) }

    LaunchedEffect(key1 = true) {
        while (countdown > 0) {
            delay(1000)
            countdown--
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.align(Alignment.Start)
        ) {
            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Navigate Back")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text("🔑", fontSize = 32.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Enter Verification Code",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "We sent an OTP to $phoneNumber.\n(Type 7777 to bypass simulation)",
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )

        Spacer(modifier = Modifier.height(32.dp))

        OutlinedTextField(
            value = otpCode,
            onValueChange = { if (it.length <= 4) otpCode = it },
            placeholder = { Text("••••") },
            textStyle = LocalTextStyle.current.copy(
                textAlign = TextAlign.Center,
                fontSize = 24.sp,
                letterSpacing = 8.sp,
                fontWeight = FontWeight.Bold
            ),
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = { if (otpCode.length == 4) onOtpSubmitted(otpCode) }
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .width(180.dp)
                .testTag("otp_input")
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { if (otpCode.length == 4) onOtpSubmitted(otpCode) },
            enabled = otpCode.length == 4,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("otp_submit_button")
        ) {
            Text("Verify OTP Session", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = if (countdown > 0) "Resend code in ${countdown}s" else "Didn't receive? Resend Code",
            fontSize = 13.sp,
            color = if (countdown > 0) MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f) else MaterialTheme.colorScheme.primary,
            modifier = Modifier.clickable(enabled = countdown == 0) { countdown = 60 }
        )
    }
}

// ==========================================
// 2. MAIN HUB (DASHBOARD & SIDEBAR PANELS)
// ==========================================

enum class DashboardSection {
    CHATS, CALLS, MINI_APPS, SYSTEM_LOGS, SETTINGS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthenticatedDashboard(viewModel: TeleViewModel) {
    var activeSection by remember { mutableStateOf(DashboardSection.CHATS) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    
    val chats by viewModel.chats.collectAsState()
    val stories by viewModel.stories.collectAsState()
    val activeChatId by viewModel.activeChatId.collectAsState()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                SidebarNavigationContent(
                    activeSection = activeSection,
                    onSectionSelected = {
                        activeSection = it
                        scope.launch { drawerState.close() }
                    },
                    viewModel = viewModel
                )
            }
        }
    ) {
        val selectedChat = chats.find { it.id == activeChatId }

        Scaffold(
            topBar = {
                if (selectedChat == null) {
                    DashboardTopBar(
                        section = activeSection,
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        viewModel = viewModel
                    )
                }
            },
            bottomBar = {
                if (selectedChat == null) {
                    DashboardBottomNavigation(
                        activeSection = activeSection,
                        onSectionSelected = { activeSection = it }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Determine active secondary UI representation
                when (activeSection) {
                    DashboardSection.CHATS -> ChatsFeedScreen(
                        chats = chats,
                        stories = stories,
                        viewModel = viewModel
                    )
                    DashboardSection.CALLS -> CallsScreen(viewModel)
                    DashboardSection.MINI_APPS -> MiniAppsScreen(viewModel)
                    DashboardSection.SYSTEM_LOGS -> AdminLogsScreen(viewModel)
                    DashboardSection.SETTINGS -> SettingsScreen(viewModel)
                }

                // Smooth overlays for Active elements (Detailed chats, story modals, call dialogues)
                AnimatedVisibility(
                    visible = selectedChat != null,
                    enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                    exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut()
                ) {
                    if (selectedChat != null) {
                        ChatRoomScreen(
                            chat = selectedChat,
                            viewModel = viewModel,
                            onBack = { viewModel.selectChat(null) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardTopBar(
    section: DashboardSection,
    onOpenMenu: () -> Unit,
    viewModel: TeleViewModel
) {
    val session by viewModel.userSession.collectAsState()

    CenterAlignedTopAppBar(
        title = {
            Text(
                text = when (section) {
                    DashboardSection.CHATS -> "Telepulse"
                    DashboardSection.CALLS -> "Encrypted Calls"
                    DashboardSection.MINI_APPS -> "Aether Apps"
                    DashboardSection.SYSTEM_LOGS -> "Database Metrics"
                    DashboardSection.SETTINGS -> "My Hub Settings"
                },
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        },
        navigationIcon = {
            IconButton(onClick = onOpenMenu) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Trigger Sidebar Navigation"
                )
            }
        },
        actions = {
            if (section == DashboardSection.CHATS) {
                IconButton(onClick = { viewModel.initiateCall("Sarah Miller", "VIDEO") }) {
                    Icon(imageVector = Icons.Default.LiveTv, contentDescription = "Simulated WebRTC Broadcast")
                }
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
        )
    )
}

@Composable
fun DashboardBottomNavigation(
    activeSection: DashboardSection,
    onSectionSelected: (DashboardSection) -> Unit
) {
    NavigationBar {
        NavigationBarItem(
            selected = activeSection == DashboardSection.CHATS,
            onClick = { onSectionSelected(DashboardSection.CHATS) },
            icon = { Icon(imageVector = Icons.Outlined.ChatBubbleOutline, contentDescription = null) },
            label = { Text("Chats") }
        )
        NavigationBarItem(
            selected = activeSection == DashboardSection.CALLS,
            onClick = { onSectionSelected(DashboardSection.CALLS) },
            icon = { Icon(imageVector = Icons.Outlined.Call, contentDescription = null) },
            label = { Text("Calls") }
        )
        NavigationBarItem(
            selected = activeSection == DashboardSection.MINI_APPS,
            onClick = { onSectionSelected(DashboardSection.MINI_APPS) },
            icon = { Icon(imageVector = Icons.Outlined.Widgets, contentDescription = null) },
            label = { Text("Apps") }
        )
        NavigationBarItem(
            selected = activeSection == DashboardSection.SETTINGS,
            onClick = { onSectionSelected(DashboardSection.SETTINGS) },
            icon = { Icon(imageVector = Icons.Outlined.Settings, contentDescription = null) },
            label = { Text("Settings") }
        )
    }
}

@Composable
fun SidebarNavigationContent(
    activeSection: DashboardSection,
    onSectionSelected: (DashboardSection) -> Unit,
    viewModel: TeleViewModel
) {
    val session by viewModel.userSession.collectAsState()
    val primaryColor = MaterialTheme.colorScheme.primary

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(280.dp)
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) {
        // User Profile Header representing current logged session
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp, top = 24.dp)
        ) {
            Column {
                AsyncImage(
                    model = session?.avatarUri ?: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
                    contentDescription = "User Avatar Profile Picture representation",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, primaryColor, CircleShape)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = session?.name ?: "Aether Admin",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = session?.phoneNumber ?: "+1 555-0199",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = session?.bio ?: "Building the future of secure communication ✨",
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        // Navigation Links
        NavigationDrawerItem(
            label = { Text("💬 All Chats Hub") },
            selected = activeSection == DashboardSection.CHATS,
            onClick = { onSectionSelected(DashboardSection.CHATS) },
            modifier = Modifier.padding(vertical = 2.dp)
        )

        NavigationDrawerItem(
            label = { Text("📞 Real-time Calling") },
            selected = activeSection == DashboardSection.CALLS,
            onClick = { onSectionSelected(DashboardSection.CALLS) },
            modifier = Modifier.padding(vertical = 2.dp)
        )

        NavigationDrawerItem(
            label = { Text("💎 Aether Mini Tools") },
            selected = activeSection == DashboardSection.MINI_APPS,
            onClick = { onSectionSelected(DashboardSection.MINI_APPS) },
            modifier = Modifier.padding(vertical = 2.dp)
        )

        NavigationDrawerItem(
            label = { Text("🛡️ System Stats & Logs") },
            selected = activeSection == DashboardSection.SYSTEM_LOGS,
            onClick = { onSectionSelected(DashboardSection.SYSTEM_LOGS) },
            modifier = Modifier.padding(vertical = 2.dp)
        )

        NavigationDrawerItem(
            label = { Text("⚙️ Settings & Wallpaper") },
            selected = activeSection == DashboardSection.SETTINGS,
            onClick = { onSectionSelected(DashboardSection.SETTINGS) },
            modifier = Modifier.padding(vertical = 2.dp)
        )

        Spacer(modifier = Modifier.weight(1f))

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        // Logout Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.logout() }
                .padding(vertical = 12.dp, horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ExitToApp,
                contentDescription = "Log out session",
                tint = MaterialTheme.colorScheme.error
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                "Sign Out Session",
                color = MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

// ==========================================
// 3. CHATS FEED SCREEN & STORIES PANEL
// ==========================================

@Composable
fun ChatsFeedScreen(
    chats: List<ChatEntity>,
    stories: List<StoryEntity>,
    viewModel: TeleViewModel
) {
    var searchQuery by remember { mutableStateOf("") }
    var storyToShow by remember { mutableStateOf<StoryEntity?>(null) }
    var activeStoryIndex by remember { mutableIntStateOf(0) }
    var isPublishingStory by remember { mutableStateOf(false) }

    val filteredChats = chats.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                (it.lastMessage ?: "").contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search chats, updates, or channels...") },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("global_search")
        )

        // Stories Bar
        StoriesHorizontalRow(
            stories = stories,
            onStoryClicked = { index, story ->
                activeStoryIndex = index
                storyToShow = story
            },
            onAddStoryClicked = { isPublishingStory = true }
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Chats list
        if (filteredChats.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔍", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "No discussions found",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    Text(
                        "Adjust filters or write to Aether AI",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(filteredChats, key = { it.id }) { chat ->
                    ChatItemRow(chat = chat, onClick = { viewModel.selectChat(chat.id) })
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 72.dp),
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f)
                    )
                }
            }
        }
    }

    // Story dialog trigger player
    if (storyToShow != null) {
        val currentActiveStory = stories.getOrNull(activeStoryIndex)
        if (currentActiveStory != null) {
            StoryPlayerDialog(
                story = currentActiveStory,
                onDismiss = { storyToShow = null },
                onNext = {
                    if (activeStoryIndex < stories.size - 1) {
                        activeStoryIndex++
                    } else {
                        storyToShow = null
                    }
                },
                onPrevious = {
                    if (activeStoryIndex > 0) {
                        activeStoryIndex--
                    }
                },
                onReact = { symbol ->
                    viewModel.reactToStory(currentActiveStory.id, symbol)
                }
            )
        } else {
            storyToShow = null
        }
    }

    // Story publishing trigger modal
    if (isPublishingStory) {
        PublishStoryDialog(
            onDismiss = { isPublishingStory = false },
            onPublish = { img, caption ->
                viewModel.publishCustomStory(img, caption)
                isPublishingStory = false
            }
        )
    }
}

@Composable
fun StoriesHorizontalRow(
    stories: List<StoryEntity>,
    onStoryClicked: (Int, StoryEntity) -> Unit,
    onAddStoryClicked: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // My Add Story Button
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .padding(end = 12.dp)
                .clickable { onAddStoryClicked() }
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Publish dynamic story",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("My Story", fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }

        // Circular Story Feeds
        stories.forEachIndexed { index, story ->
            val indicatorColor = if (story.reaction != null) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .clickable { onStoryClicked(index, story) }
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .drawBehind {
                            drawCircle(
                                color = indicatorColor,
                                radius = size.minDimension / 2f + 2.dp.toPx(),
                                style = Stroke(width = 2.dp.toPx())
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = story.senderAvatar ?: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150",
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = story.senderName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 64.dp)
                    )
                    if (story.reaction != null) {
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(story.reaction ?: "", fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatItemRow(chat: ChatEntity, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = chat.avatarUrl ?: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150",
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
        )

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = chat.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (chat.isPinned) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                val formattedTime = remember(chat.lastMessageTime) {
                    val date = java.util.Date(chat.lastMessageTime)
                    val format = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
                    format.format(date)
                }
                Text(
                    text = formattedTime,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = chat.lastMessage ?: "",
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }

        if (chat.unreadCount > 0) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = chat.unreadCount.toString(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

// ==========================================
// 4. DETAILED CHAT ROOM (GRADIENTS, AI COPT)
// ==========================================

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ChatRoomScreen(
    chat: ChatEntity,
    viewModel: TeleViewModel,
    onBack: () -> Unit
) {
    var rawInputText by remember { mutableStateOf("") }
    val messages by viewModel.activeMessages.collectAsState()
    val aiProcessing by viewModel.aiProcessing.collectAsState()
    val summaryText by viewModel.chatSummaryResult.collectAsState()

    var showAiActionsMsg by remember { mutableStateOf<MessageEntity?>(null) }
    var selectedLanguageToTranslate by remember { mutableStateOf("English") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            viewModel.initiateCall(chat.name, "VOICE")
                        }
                    ) {
                        AsyncImage(
                            model = chat.avatarUrl ?: "",
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = chat.name,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (chat.type == "BOT") "system assistant bot" else "online",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.initiateCall(chat.name, "VIDEO") }) {
                        Icon(imageVector = Icons.Default.VideoCall, contentDescription = "Video Call")
                    }
                    IconButton(onClick = { viewModel.initiateCall(chat.name, "VOICE") }) {
                        Icon(imageVector = Icons.Default.Phone, contentDescription = "Voice Call")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(4.dp)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    // Luxury Telegram Chat Gradient theme pairing background mapping
                    valThemeGradient()
                )
        ) {
            // Summary Banner on top if requested
            AnimatedVisibility(
                visible = summaryText.isNotBlank(),
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Aether Chat Quick Summary", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(summaryText, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }

            // Quick actions toolbar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.15f))
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (aiProcessing) "⚡ AI is thinking..." else "AI Co-Pilot ready",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )

                Row {
                    Card(
                        modifier = Modifier
                            .clickable { viewModel.summarizeChatFeed() }
                            .padding(end = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            "Summarize",
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Card(
                        modifier = Modifier.clickable {
                            viewModel.sendMessage(
                                "[Simulated Photo Attachment]",
                                type = "IMAGE",
                                mediaUri = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400"
                            )
                        },
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f))
                    ) {
                        Text(
                            "+ Share Media",
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Messages Stream
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                reverseLayout = false
            ) {
                items(messages, key = { it.id }) { msg ->
                    ChatBubble(
                        message = msg,
                        onPressOptions = { showAiActionsMsg = msg }
                    )
                }
            }

            // Animated Typing indicator
            AnimatedVisibility(visible = aiProcessing) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .fillMaxWidth()
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            "⚡ Bot is drafting prompt translation summaries...",
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Bottom Input Bar
            BottomChatWritingFields(
                text = rawInputText,
                onValueChange = { rawInputText = it },
                onSend = {
                    viewModel.sendMessage(rawInputText)
                    rawInputText = ""
                },
                onSendVoice = {
                    viewModel.sendMessage(
                        "🎙️ Simulated Voice Note (0:15s)",
                        type = "VOICE",
                        mediaUri = "[VoiceNoteBufferBinaryStream]"
                    )
                }
            )
        }
    }

    // Modal Sheet Trigger showing AI tools per single message
    if (showAiActionsMsg != null) {
        val targetMsg = showAiActionsMsg!!
        Dialog(
            onDismissRequest = { showAiActionsMsg = null },
            properties = DialogProperties(usePlatformDefaultWidth = true)
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "⚡ Aether AI Co-Pilot",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Execute intelligent Gemini features safely",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        "\"${targetMsg.text}\"",
                        fontSize = 14.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                            .fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Translate Select Field
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Target Language:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Row {
                            listOf("Spanish", "French", "Chinese").forEach { lang ->
                                FilterChip(
                                    selected = selectedLanguageToTranslate == lang,
                                    onClick = { selectedLanguageToTranslate = lang },
                                    label = { Text(lang, fontSize = 11.sp) },
                                    modifier = Modifier.padding(horizontal = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.translateMessage(targetMsg, selectedLanguageToTranslate)
                            showAiActionsMsg = null
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Translate, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Translate via Gemini")
                    }

                    // Trigger Voice transcription if message is a voice note
                    if (targetMsg.type == "VOICE") {
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                viewModel.transcribeVoice(targetMsg)
                                showAiActionsMsg = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.RecordVoiceOver, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Transcribe Voice Note")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = {
                                viewModel.sendMessage("[Forwarded: ${targetMsg.text}]")
                                showAiActionsMsg = null
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Forward")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = {
                                viewModel.deleteMessage(targetMsg.id)
                                showAiActionsMsg = null
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Delete")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun ChatBubble(message: MessageEntity, onPressOptions: () -> Unit) {
    val layoutAlign = if (message.isMe) Alignment.End else Alignment.Start
    val bubbleColor = if (message.isMe) {
        if (isSystemInDarkTheme()) Color(0xFF2B5278) else Color(0xFFE2F7FD)
    } else {
        if (isSystemInDarkTheme()) Color(0xFF182533) else Color(0xFFFFFFFF)
    }
    val contentColor = if (message.isMe && !isSystemInDarkTheme()) Color.Black else MaterialTheme.colorScheme.onSurface

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = layoutAlign
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (message.isMe) 16.dp else 4.dp,
                bottomEnd = if (message.isMe) 4.dp else 16.dp
            ),
            colors = CardDefaults.cardColors(containerColor = bubbleColor),
            modifier = Modifier
                .widthIn(max = 290.dp)
                .combinedClickable(
                    onClick = onPressOptions,
                    onLongClick = onPressOptions
                )
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                // Handle Sender Label if in a group
                if (!message.isMe) {
                    Text(
                        text = message.senderName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }

                // Handle rich components (Image attachments)
                if (message.type == "IMAGE" && message.mediaUri != null) {
                    AsyncImage(
                        model = message.mediaUri,
                        contentDescription = "Shared Attachment",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Standard Core Text
                Text(
                     text = message.text,
                     fontSize = 14.sp,
                     color = contentColor
                )

                // Render dynamic AI translation insertions
                if (message.isTranslated && message.translatedText != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    ) {
                        Column {
                            Text("🤖 AI Translate:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(message.translatedText, fontSize = 12.sp, color = contentColor)
                        }
                    }
                }

                // Render dynamic Audio Transcriptions
                if (message.isTranscribed && message.transcribedText != null) {
                     Spacer(modifier = Modifier.height(6.dp))
                     Box(
                         modifier = Modifier
                             .background(Color.Black.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                             .padding(6.dp)
                     ) {
                         Column {
                             Text("📝 Voice Transcription:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                             Text(message.transcribedText, fontSize = 12.sp, color = contentColor)
                         }
                     }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Metadata details (timestamp, checkmarks)
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val formattedTime = remember(message.timestamp) {
                        val date = java.util.Date(message.timestamp)
                        val format = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
                        format.format(date)
                    }
                    Text(
                        text = formattedTime,
                        fontSize = 10.sp,
                        color = contentColor.copy(alpha = 0.6f)
                    )
                    if (message.isMe) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.DoneAll,
                            contentDescription = "Read Receipt checks",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BottomChatWritingFields(
    text: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    onSendVoice: () -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .navigationBarsPadding(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onSendVoice) {
            Icon(imageVector = Icons.Default.Mic, contentDescription = "Simulate voice recording input")
        }

        OutlinedTextField(
            value = text,
            onValueChange = onValueChange,
            placeholder = { Text("Write a secure message...") },
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp),
            singleLine = true,
            trailingIcon = {
                if (text.isNotBlank()) {
                    IconButton(
                        onClick = {
                            onSend()
                            keyboardController?.hide()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send message file"
                        )
                    }
                }
            }
        )
    }
}

// Helper gradient resolver
@Composable
fun valThemeGradient(): Brush {
    val background = MaterialTheme.colorScheme.background
    return Brush.verticalGradient(
        colors = listOf(
            background,
            background.copy(alpha = 0.85f),
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
        )
    )
}

// ==========================================
// 5. STOPIES DYNAMIC DIALOG LAYOUT HANDLER
// ==========================================

@Composable
fun StoryPlayerDialog(
    story: StoryEntity,
    onDismiss: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onReact: (String) -> Unit
) {
    var tickProgress by remember { mutableStateOf(0f) }

    LaunchedEffect(key1 = story) {
        tickProgress = 0f
        val increments = 100
        for (i in 1..increments) {
            delay(50) // 5 seconds total duration playing
            tickProgress = i / increments.toFloat()
        }
        onNext()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Background Image display
            AsyncImage(
                model = story.imageUrl,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .align(Alignment.Center)
            )

            // Top Progress Tickers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, start = 16.dp, end = 16.dp)
                    .align(Alignment.TopCenter)
            ) {
                LinearProgressIndicator(
                    progress = { tickProgress },
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.3f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                )
            }

            // Story profile heading label
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 60.dp, start = 16.dp, end = 16.dp)
                    .align(Alignment.TopCenter),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = story.senderAvatar ?: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150",
                    contentDescription = null,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = story.senderName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close player", tint = Color.White)
                }
            }

            // Gestured screen taps
            Row(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = onPrevious
                        )
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = onNext
                        )
                )
            }

            // Bottom Caption & Reaction panel
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                        )
                    )
                    .padding(24.dp)
            ) {
                if (story.caption != null) {
                    Text(
                        text = story.caption,
                        color = Color.White,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }

                Text(
                     "TAP TO REACT:", 
                     color = Color.White.copy(alpha = 0.6f),
                     fontSize = 11.sp, 
                     fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("❤️", "🔥", "😂", "🚀", "👏", "😮").forEach { emotion ->
                        Button(
                            onClick = { onReact(emotion) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f)),
                            modifier = Modifier.size(44.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(emotion, fontSize = 18.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PublishStoryDialog(
    onDismiss: () -> Unit,
    onPublish: (String, String?) -> Unit
) {
    var rawStoryUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?w=600") }
    var captionText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Publish to Your Stories", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = rawStoryUrl,
                    onValueChange = { rawStoryUrl = it },
                    label = { Text("Story Image URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = captionText,
                    onValueChange = { captionText = it },
                    label = { Text("Add Caption") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onPublish(rawStoryUrl, captionText) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Publish")
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. REAL-TIME ENCRYPTED CALLING SCREEN UI
// ==========================================

@Composable
fun CallsScreen(viewModel: TeleViewModel) {
    val isCallActive by viewModel.isCallActive.collectAsState()
    val callStateMessage by viewModel.callStateMessage.collectAsState()
    val callerName by viewModel.callerName.collectAsState()
    val callType by viewModel.callType.collectAsState()
    val noiseCancel by viewModel.noiseCancelEnabled.collectAsState()
    val screenShare by viewModel.screenShareEnabled.collectAsState()

    if (isCallActive) {
        // High fidelity fullscreen caller animation sheet
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A))
        ) {
            // Infinite wave circles pulsing visually
            val transition = rememberInfiniteTransition(label = "pulse")
            val scalePulse by transition.animateFloat(
                initialValue = 0.8f,
                targetValue = 1.3f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1500, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "wave_oscillator"
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        drawCircle(
                            color = Color(0xFF2563EB).copy(alpha = 0.15f),
                            radius = (size.minDimension / 3.5f) * scalePulse
                        )
                    }
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Connection Metadata Info
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 48.dp)
                ) {
                    Text(
                        "TELEPULSE ENCRYPTED LINK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8),
                        letterSpacing = 2.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (callType == "VIDEO") "📹" else "📞", fontSize = 48.sp)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = callerName,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = callStateMessage,
                        fontSize = 14.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }

                // Call metrics information
                Text(
                    text = "WebRTC Handshake: Completed • Latency: 42ms • PacketLoss: 0.0%",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.4f),
                    textAlign = TextAlign.Center
                )

                // Bottom actions call toggles panel
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        // Noise-cancel filter
                        OutlinedButton(
                            onClick = { viewModel.toggleNoiseCancel() },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = if (noiseCancel) Color.White else Color.White.copy(alpha = 0.5f),
                                containerColor = if (noiseCancel) Color.White.copy(alpha = 0.15f) else Color.Transparent
                            ),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                        ) {
                            Icon(imageVector = if (noiseCancel) Icons.Default.VolumeUp else Icons.Default.VolumeMute, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("DSP Noise")
                        }

                        // Screen sharing
                        OutlinedButton(
                            onClick = { viewModel.toggleScreenShare() },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = if (screenShare) Color.White else Color.White.copy(alpha = 0.5f),
                                containerColor = if (screenShare) Color.White.copy(alpha = 0.15f) else Color.Transparent
                            ),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Screen")
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Terminate Line action
                    Button(
                        onClick = { viewModel.endCall() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("end_call_button")
                    ) {
                        Icon(imageVector = Icons.Default.CallEnd, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Terminate Peer Connection", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    } else {
        // Simple Call Logs History Screen
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("📞", fontSize = 64.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "No active stream links",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "You can start custom WebRTC peer-to-peer secure audio/video call lines by tapping on contact headers within your threads.",
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { viewModel.initiateCall("Alex Rivera", "VOICE") },
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Call, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Call Contact (Demo)")
            }
        }
    }
}

// ==========================================
// 7. MINI APPS SYSTEMS (PULSE GAME, WALLET)
// ==========================================

@Composable
fun MiniAppsScreen(viewModel: TeleViewModel) {
    val tokens by viewModel.miniAppTokens.collectAsState()
    val walletUsd by viewModel.walletBalanceUsd.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Card(
             modifier = Modifier.fillMaxWidth(),
             colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "💎 Telepulse Mini-App Engine",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    "Run secure client-side applications on-the-fly, integrating payment processors, custom wallets, and AI bots directly inside the platform.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Cryptowallet simulator
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                     "AETHER CRYPTO WALLET",
                     fontSize = 11.sp, 
                     fontWeight = FontWeight.Bold, 
                     color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "$${String.format("%.2f", walletUsd)} USD",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "$tokens PULSE Token Asset Blocks",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.claimTokens() },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.Token, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Mint Pulse Tokens (+10)")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Cognitive Reaction Trainer Mini-Game
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            var activeGameText by remember { mutableStateOf("TAP TO START REACTION TRAIN") }
            var targetTime by remember { mutableLongStateOf(0L) }
            var isRedState by remember { mutableStateOf(false) }

            val cardColor = if (isRedState) Color(0xFFDC2626) else MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(cardColor)
                    .clickable {
                        when {
                            !isRedState && activeGameText.contains("START") -> {
                                activeGameText = "Wait for GREEN..."
                                isRedState = true
                                targetTime = System.currentTimeMillis() + (1000..3000).random()
                            }

                            isRedState && System.currentTimeMillis() < targetTime -> {
                                activeGameText = "TRIGGER FAILURE! Touched too early! Tap to retry."
                                isRedState = false
                            }

                            isRedState && System.currentTimeMillis() >= targetTime -> {
                                val elapsed = System.currentTimeMillis() - targetTime
                                activeGameText = "SUCCESS! Your reaction: ${elapsed}ms. Tap to retry!"
                                isRedState = false
                                viewModel.claimTokens()
                            }

                            else -> {
                                activeGameText = "TAP TO START REACTION TRAIN"
                            }
                        }
                    }
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "🎮 REACTION-SPEED MINI-GAME",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isRedState) Color.White else MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = activeGameText,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = if (isRedState) Color.White else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

// ==========================================
// 8. ADMIN DASHBOARD & ADVANCED logs
// ==========================================

@Composable
fun AdminLogsScreen(viewModel: TeleViewModel) {
    val logMessages by viewModel.totalLogMessages.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Dynamic dashboard cards showing mock diagnostic ratios
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Daily Active", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    Text("14,240", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Active Session Sync", fontSize = 10.sp, color = Color.Gray)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Delivery Latency", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    Text("18ms", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("WebSocket handshake", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
             modifier = Modifier.fillMaxWidth(),
             colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Security Protocol", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("All client chats are encapsulated using end-to-end SQLite local AES block hashes and synced utilizing simulated secure MTProto frames.", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
             "REAL-TIME DIAGNOSTIC SYSTEM LOGS", 
             fontSize = 11.sp, 
             fontWeight = FontWeight.Bold, 
             modifier = Modifier.padding(vertical = 4.dp)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.Black, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            items(logMessages.reversed()) { log ->
                Text(
                    text = log,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = Color.Green,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}

// ==========================================
// 9. SETTINGS PANEL (THEMES CONFIGURATION)
// ==========================================

@Composable
fun SettingsScreen(viewModel: TeleViewModel) {
    val themeType by viewModel.appTheme.collectAsState()
    val session by viewModel.userSession.collectAsState()

    var profileName by remember { mutableStateOf(session?.name ?: "Aether Admin") }
    var profileBio by remember { mutableStateOf(session?.bio ?: "Building the future of secure communication ✨") }
    var biometricEnabled by remember { mutableStateOf(session?.biometricEnabled ?: false) }
    var passCodeInput by remember { mutableStateOf(session?.passCode ?: "1234") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Theme Shifting Module
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "🎨 Application Theme Engine",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(12.dp))

                listOf(
                    Triple(TelepulseThemeType.TELEGRAM_DARK, "Telegram Dark", "Classic Slate-blue"),
                    Triple(TelepulseThemeType.TELEGRAM_LIGHT, "Telegram Light", "Fresh Clean White"),
                    Triple(TelepulseThemeType.AMOLED_PREMIUM, "AMOLED Premium", "Stunning Pitch Black"),
                    Triple(TelepulseThemeType.COSMIC_EMERALD, "Cosmic Emerald", "Glowing Jungle Green"),
                    Triple(TelepulseThemeType.VINTAGE_AMBER, "Vintage Amber", "Cyberpunk CRT Terminal glow")
                ).forEach { (type, title, desc) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.changeSystemTheme(type) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                        }
                        RadioButton(
                            selected = themeType == type,
                            onClick = { viewModel.changeSystemTheme(type) }
                        )
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Profile Configuration
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "👤 Profile Sync Configurations",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = profileName,
                    onValueChange = { profileName = it },
                    label = { Text("Display Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = profileBio,
                    onValueChange = { profileBio = it },
                    label = { Text("Short Bio") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = passCodeInput,
                    onValueChange = { passCodeInput = it },
                    label = { Text("App Locker Passcode") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Biometric Fingerprint Lock", fontSize = 14.sp)
                    Switch(
                        checked = biometricEnabled,
                        onCheckedChange = { biometricEnabled = it }
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        viewModel.updateProfileSettings(
                            profileName,
                            profileBio,
                            biometricEnabled,
                            passCodeInput
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Save Changes locally", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
