package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Telegram standard theme shades
val TelegramBlueLight = Color(0xFF2481CC)
val TelegramBlueDark = Color(0xFF2AABEE)
val ChatBgLight = Color(0xFFECEFF1)
val ChatBgDark = Color(0xFF0E1621)

// Luxury dark AMOLED palette
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF121212)
val AmoledCard = Color(0xFF1E1E1E)
val AmoledAccent = Color(0xFF9D4EDD) // Stunning cyberpunk purple

// Cosmic Emerald palette
val CosmicForest = Color(0xFF081411)
val CosmicLeaf = Color(0xFF0F2C24)
val CosmicBrightGreen = Color(0xFF39FF14) // Glowing neon green
val CosmicCard = Color(0xFF133F33)

// Vintage Cyberpunk/Amber palette
val CyberpunkObsidian = Color(0xFF1C1300)
val CyberpunkBackground = Color(0xFF0A0700)
val CyberpunkAmber = Color(0xFFFFA000) // Retro amber CRT terminal glow
val CyberpunkCard = Color(0xFF332000)

// Helper shades for common widgets
val BubbleMeLight = Color(0xFFE2F7FD)
val BubbleOtherLight = Color(0xFFFFFFFF)
val BubbleMeDark = Color(0xFF2B5278)
val BubbleOtherDark = Color(0xFF182533)
