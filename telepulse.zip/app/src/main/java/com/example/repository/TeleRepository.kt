package com.example.repository

import android.content.Context
import com.example.database.*
import com.example.network.GeminiApiClient
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.util.UUID

class TeleRepository(private val db: AppDatabase) {

    val allChats: Flow<List<ChatEntity>> = db.chatDao().getAllChats()
    val allStories: Flow<List<StoryEntity>> = db.storyDao().getAllStories()
    val userSession: Flow<UserSessionEntity?> = db.userSessionDao().getSessionFlow()

    fun getMessagesForChat(chatId: Long): Flow<List<MessageEntity>> {
        return db.messageDao().getMessagesForChat(chatId)
    }

    /**
     * Initializes beautiful default data on first-time launch so the user has an inviting viewport.
     */
    suspend fun initializeDefaultDataIfRequired() {
        // 1. Session Setup
        val currentSession = db.userSessionDao().getSessionDirect()
        if (currentSession == null) {
            db.userSessionDao().insertSession(UserSessionEntity(
                isLoggedIn = true,
                name = "Aether Admin",
                phoneNumber = "+1 (555) 789-2041",
                bio = "Passionate designer crafting high-fidelity Android products with Compose"
            ))
        }

        // 2. Chat Feed Check
        val existingChats = db.chatDao().getAllChats().firstOrNull() ?: emptyList()
        if (existingChats.isEmpty()) {
            val now = System.currentTimeMillis()
            
            // Insert default chats representational of different Telegram hubs
            val chats = listOf(
                ChatEntity(
                    id = 101L,
                    name = "⚡ Aether AI Bot",
                    type = "BOT",
                    lastMessage = "Hey and welcome! I am your real-time Gemini assistant. Ask me anything or tap any message to translate it instantly!",
                    lastMessageTime = now - 50000,
                    avatarUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150", 
                    isPinned = true,
                    unreadCount = 1
                ),
                ChatEntity(
                    id = 102L,
                    name = "🚀 Jetpack Compose HQ",
                    type = "GROUP",
                    lastMessage = "Alex: Edge-to-edge support is now mandatory in our projects and looks incredibly sleek!",
                    lastMessageTime = now - 1800000,
                    avatarUrl = "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=150",
                    isPinned = false,
                    unreadCount = 3
                ),
                ChatEntity(
                    id = 103L,
                    name = "📣 Telepulse Broadcast",
                    type = "CHANNEL",
                    lastMessage = "Our customized 24-hour Stories, WebRTC layout displays, SQLite caching layers, and security tokens are ready! 🛠️",
                    lastMessageTime = now - 3600000,
                    avatarUrl = "https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?w=150",
                    isPinned = false,
                    unreadCount = 0
                ),
                ChatEntity(
                    id = 104L,
                    name = "Sarah Miller",
                    type = "PRIVATE",
                    lastMessage = "Hey! Did you check out the new color themes within the app? The AMOLED option is insane!",
                    lastMessageTime = now - 86400000,
                    avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
                    isPinned = false,
                    unreadCount = 0
                )
            )
            db.chatDao().insertChats(chats)

            // Insert initial message history
            db.messageDao().insertMessage(MessageEntity(
                chatId = 101L,
                senderName = "Aether AI Bot",
                text = "Hello! I am Telepulse's integrated generative AI bot assistant. Let's explore smart features together!",
                timestamp = now - 60000,
                isMe = false,
                type = "TEXT"
            ))
            db.messageDao().insertMessage(MessageEntity(
                chatId = 101L,
                senderName = "Aether AI Bot",
                text = "Type any request here, or tap a message to translate, summarize, or transcribe voice notes.",
                timestamp = now - 50000,
                isMe = false,
                type = "TEXT"
            ))

            // Group Messages
            db.messageDao().insertMessage(MessageEntity(
                chatId = 102L,
                senderName = "Sarah",
                text = "Guys, how are we handling the custom adaptive icons?",
                timestamp = now - 2000000,
                isMe = false
            ))
            db.messageDao().insertMessage(MessageEntity(
                chatId = 102L,
                senderName = "Alex",
                text = "Edge-to-edge support is now mandatory in our projects and looks incredibly sleek!",
                timestamp = now - 1800000,
                isMe = false
            ))

            // Channel Messages
            db.messageDao().insertMessage(MessageEntity(
                chatId = 103L,
                senderName = "Telepulse Broadcast",
                text = "Welcome to the official Telepulse broadcast feed! Stay tuned for product announcements, security audits, and cool tips.",
                timestamp = now - 7200000,
                isMe = false
            ))
            db.messageDao().insertMessage(MessageEntity(
                chatId = 103L,
                senderName = "Telepulse Broadcast",
                text = "Our customized 24-hour Stories, WebRTC layout displays, SQLite caching layers, and security tokens are ready! 🛠️",
                timestamp = now - 3600000,
                isMe = false
            ))

            // Private Chat Messages
            db.messageDao().insertMessage(MessageEntity(
                chatId = 104L,
                senderName = "Sarah Miller",
                text = "Hey! Did you check out the new color themes within the app? The AMOLED option is insane!",
                timestamp = now - 86400000,
                isMe = false
            ))
        }

        // 3. Populate Stories
        val existingStories = db.storyDao().getAllStories().firstOrNull() ?: emptyList()
        if (existingStories.isEmpty()) {
            val now = System.currentTimeMillis()
            val stories = listOf(
                StoryEntity(
                    senderName = "Aether AI",
                    senderAvatar = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150",
                    imageUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=500",
                    caption = "Synthesizing original vector wallpapers... 💫",
                    timestamp = now - 3000000
                ),
                StoryEntity(
                    senderName = "Sarah Miller",
                    senderAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
                    imageUrl = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=500",
                    caption = "Sunday hikes are the best! ⛰️🌳",
                    timestamp = now - 7200000
                ),
                StoryEntity(
                    senderName = "Alex Rivera",
                    senderAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
                    imageUrl = "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=500",
                    caption = "Late night setups and coffee cups ☕💻",
                    timestamp = now - 18000000
                )
            )
            for (story in stories) {
                db.storyDao().insertStory(story)
            }
        }
    }

    // --- Message handling actions ---
    suspend fun sendMessage(chatId: Long, text: String, type: String = "TEXT", mediaUri: String? = null) {
        val now = System.currentTimeMillis()
        val message = MessageEntity(
            chatId = chatId,
            senderName = "Me",
            text = text,
            timestamp = now,
            isMe = true,
            type = type,
            mediaUri = mediaUri
        )

        db.messageDao().insertMessage(message)
        db.chatDao().updateLastMessage(chatId, text, now, 0)

        // If chatting with the AI bot (id: 101), trigger automated response via Gemini!
        if (chatId == 101L) {
            // Trigger AI Typing status simulation, calling the Gemini API
            val responseText = GeminiApiClient.queryGemini(text)
            val aiMessage = MessageEntity(
                chatId = 101L,
                senderName = "⚡ Aether AI Bot",
                text = responseText,
                timestamp = System.currentTimeMillis(),
                isMe = false
            )
            db.messageDao().insertMessage(aiMessage)
            db.chatDao().updateLastMessage(101L, responseText, System.currentTimeMillis(), 1)
        }
    }

    suspend fun translateMessage(message: MessageEntity, targetLanguage: String): MessageEntity {
        val instruction = "You are a professional compiler translator. Translate the text directly to $targetLanguage, preserving emojis and return ONLY the translated string, absolutely nothing else."
        val prompt = message.text
        val translated = GeminiApiClient.queryGemini(prompt, systemInstruction = instruction)
        val updated = message.copy(isTranslated = true, translatedText = translated)
        db.messageDao().updateMessage(updated)
        return updated
    }

    suspend fun transcribeMessage(message: MessageEntity): MessageEntity {
        // Verify audio transcription simulation trigger
        val instruction = "The user has provided an audio voice note which is stored as binary data. Translate/transcribe this audio file simulation directly to text. Return ONLY the transcribed text."
        val prompt = "Transcribe this simulated voice recording duration of 15 seconds"
        val transcribed = GeminiApiClient.queryGemini(prompt, systemInstruction = instruction)
        val updated = message.copy(isTranscribed = true, transcribedText = transcribed)
        db.messageDao().updateMessage(updated)
        return updated
    }

    suspend fun summarizeChat(chatId: Long, messages: List<MessageEntity>): String {
        if (messages.isEmpty()) return "There are no messages in this Chat to summarize."
        val conversationText = messages.joinToString("\n") { "${it.senderName}: ${it.text}" }
        val prompt = "Following is a chat log. Write a concise, 1-sentence recap of what's described in this conversation. Keep it professional.\n$conversationText"
        return GeminiApiClient.queryGemini(prompt, systemInstruction = "You are a helpful chat log summarizer assistant.")
    }

    suspend fun deleteMessage(messageId: Long) {
        db.messageDao().deleteMessageById(messageId)
    }

    suspend fun clearHistory(chatId: Long) {
        db.messageDao().clearChatHistory(chatId)
    }

    // --- Story interactions ---
    suspend fun publishStory(imageUrl: String, caption: String?) {
        val story = StoryEntity(
            senderName = "Me",
            senderAvatar = null, // Will use dynamic user profile avatar representation
            imageUrl = imageUrl,
            caption = caption,
            timestamp = System.currentTimeMillis()
        )
        db.storyDao().insertStory(story)
    }

    suspend fun addStoryReaction(storyId: Long, reaction: String) {
        db.storyDao().reactToStory(storyId, reaction)
    }

    suspend fun updateSessionSettings(name: String, bio: String, biometric: Boolean, passString: String?) {
        db.userSessionDao().updateSettings(biometric, passString, name, bio)
    }

    suspend fun updateLoginState(isLoggedIn: Boolean) {
        db.userSessionDao().setLoginStatus(isLoggedIn)
    }

    suspend fun clearUnread(chatId: Long) {
        db.chatDao().clearUnread(chatId)
    }
}
